<?php
// Heading
$_['heading_title']    = 'Nova Floating Button';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Nova Floating Button module!';
$_['text_edit']        = 'Edit Nova Floating Button Module';

// Entry
$_['entry_link']       = 'Link';
$_['entry_image']      = 'Image';
$_['entry_width']      = 'Width';
$_['entry_height']     = 'Height';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify category module!';
$_['error_link']       = 'Link required!';
$_['error_width']      = 'Width required!';
$_['error_height']     = 'Height required!';